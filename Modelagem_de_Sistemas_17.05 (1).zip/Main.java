public class Main {
	public static void Main(String[] args) {
		Aluno S = new Aluno("Samuel", "798.0455.336-22", "08/01/2004";
		System.out.println("Nome: " + S.nome + " CPF: " + S.CPF + " Data de nascimento: " + S.data_nascimento);	
	}
}