public class Professor extends Pessoa {
  public double salario;
  public String disciplina;

public Professor (String nome, String CPF, String data_nascimento){
  super(nome, CPF, data_nascimento);
 } 
}