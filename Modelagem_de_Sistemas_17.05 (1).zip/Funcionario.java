public class Funcionario extends Pessoa {
  public double salario;
	public String data_admissao;
	public String cargo;

public Funcionario (String nome, String CPF, String data_nascimento){
		super(nome, CPF, data_nascimento);
 }
}