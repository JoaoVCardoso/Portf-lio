public class Aluno extends Pessoa {
  public String matricula;

public Aluno(String nome, String CPF, String data_nascimento) {
		super(nome, CPF, data_nascimento);
 }
}