public class Pessoa {
  private String CPF;
  private String nome;
  private String data_nascimento;

public Pessoa (String _nome, String _cpf, String _data) {
	this.nome = nome;
  this.CPF = CPF;
  this.data_nascimento = data_nascimento;
 }
}